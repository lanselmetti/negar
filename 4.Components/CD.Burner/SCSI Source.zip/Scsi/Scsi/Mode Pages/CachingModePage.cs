﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Helper;

namespace Scsi
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class CachingModePage : ModePage
	{
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private const byte DEMAND_READ_RETENTION_PRIORITY_MASK = 0xF0;
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private const byte DEMAND_WRITE_RETENTION_PRIORITY_MASK = 0x0F;

		public CachingModePage() : base(ModePageCode.Caching) { }

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private byte byte2;
		public bool InitiatorControl { get { return Bits.GetBit(this.byte2, 7); } set { this.byte2 = Bits.SetBit(this.byte2, 7, value); } }
		public bool AbortPrefetch { get { return Bits.GetBit(this.byte2, 6); } set { this.byte2 = Bits.SetBit(this.byte2, 6, value); } }
		public bool CacheAnalysisPermitted { get { return Bits.GetBit(this.byte2, 5); } set { this.byte2 = Bits.SetBit(this.byte2, 5, value); } }
		public bool Discontinuity { get { return Bits.GetBit(this.byte2, 4); } set { this.byte2 = Bits.SetBit(this.byte2, 4, value); } }
		public bool SizeEnable { get { return Bits.GetBit(this.byte2, 3); } set { this.byte2 = Bits.SetBit(this.byte2, 3, value); } }
		public bool WritebackCacheEnable { get { return Bits.GetBit(this.byte2, 2); } set { this.byte2 = Bits.SetBit(this.byte2, 2, value); } }
		public bool MultiplicationFactor { get { return Bits.GetBit(this.byte2, 1); } set { this.byte2 = Bits.SetBit(this.byte2, 1, value); } }
		public bool ReadCacheDisable { get { return Bits.GetBit(this.byte2, 0); } set { this.byte2 = Bits.SetBit(this.byte2, 0, value); } }
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private byte byte3;
		public DemandReadRetentionPriority DemandReadRetentionPriority
		{
			get { return (DemandReadRetentionPriority)Bits.GetValueMask(this.byte3, 4, DEMAND_READ_RETENTION_PRIORITY_MASK); }
			set { this.byte3 = Bits.PutValueMask(this.byte3, (byte)value, 4, DEMAND_READ_RETENTION_PRIORITY_MASK); }
		}
		public DemandWriteRetentionPriority DemandWriteRetentionPriority
		{
			get { return (DemandWriteRetentionPriority)Bits.GetValueMask(this.byte3, 4, DEMAND_WRITE_RETENTION_PRIORITY_MASK); }
			set { this.byte3 = Bits.PutValueMask(this.byte3, (byte)value, 4, DEMAND_WRITE_RETENTION_PRIORITY_MASK); }
		}
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private ushort _DisablePrefetchTransferBlockCount;
		public ushort DisablePrefetchTransferBlockCount { get { return Bits.BigEndian(this._DisablePrefetchTransferBlockCount); } set { this._DisablePrefetchTransferBlockCount = Bits.BigEndian(value); } }
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private ushort _MinimumPrefetch;
		public ushort MinimumPrefetch { get { return Bits.BigEndian(this._MinimumPrefetch); } set { this._MinimumPrefetch = Bits.BigEndian(value); } }
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private ushort _MaximumPrefetch;
		public ushort MaximumPrefetch { get { return Bits.BigEndian(this._MaximumPrefetch); } set { this._MaximumPrefetch = Bits.BigEndian(value); } }
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private ushort _MaximumPrefetchCeiling;
		public ushort MaximumPrefetchCeiling { get { return Bits.BigEndian(this._MaximumPrefetchCeiling); } set { this._MaximumPrefetchCeiling = Bits.BigEndian(value); } }
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private byte byte12;
		public bool ForceSequentialWrite { get { return Bits.GetBit(this.byte12, 7); } set { this.byte12 = Bits.SetBit(this.byte12, 7, value); } }
		public bool LogicalBlockCacheSegmentSize { get { return Bits.GetBit(this.byte12, 6); } set { this.byte12 = Bits.SetBit(this.byte12, 6, value); } }
		public bool DisableReadAhead { get { return Bits.GetBit(this.byte12, 5); } set { this.byte12 = Bits.SetBit(this.byte12, 5, value); } }
		public bool NonvolatileCacheDisabled { get { return Bits.GetBit(this.byte12, 0); } set { this.byte12 = Bits.SetBit(this.byte12, 0, value); } }
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private byte _NumberOfCacheSegments;
		public byte NumberOfCacheSegments { get { return this._NumberOfCacheSegments; } set { this._NumberOfCacheSegments = value; } }
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private ushort _CacheSegmentSize;
		public ushort CacheSegmentSize { get { return Bits.BigEndian(this._CacheSegmentSize); } set { this._CacheSegmentSize = Bits.BigEndian(value); } }
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
#pragma warning disable 0169
		private byte byte16;
#pragma warning restore 0169
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private byte _byte17; //MSB
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private byte _byte18;
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private byte _byte19; //LSB
		[Obsolete]
		public uint NonCacheSegmentSize
		{
			get { unchecked { return (uint)this._byte19 | ((uint)this._byte18 << 8) | ((uint)this._byte17 << 16); } }
			set { unchecked { this._byte19 = (byte)(value >> 0); this._byte18 = (byte)(value >> 8); this._byte17 = (byte)(value >> 16); } }
		}
	}

	public enum DemandReadRetentionPriority : byte
	{
		NoDistinction = 0x0,
		LowerReadPriority = 0x1,
		ZeroReadPriority = 0xF,
	}

	public enum DemandWriteRetentionPriority : byte
	{
		NoDistinction = 0x0,
		LowerWritePriority = 0x1,
		ZeroWritePriority = 0xF,
	}
}