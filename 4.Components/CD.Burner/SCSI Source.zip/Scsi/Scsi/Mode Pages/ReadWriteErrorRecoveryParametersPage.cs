﻿using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Helper;

namespace Scsi
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class ReadWriteErrorRecoveryParametersPage : ModePage
	{
		public ReadWriteErrorRecoveryParametersPage() : base(ModePageCode.ReadWriteErrorRecoveryParameters) { }

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private byte errorRecoveryParameter;
		[DisplayName("Automatic Write Reallocation")]
		public bool AutomaticWriteReallocationEnabled { get { return Bits.GetBit(this.errorRecoveryParameter, 7); } set { this.errorRecoveryParameter = Bits.SetBit(this.errorRecoveryParameter, 7, value); } }
		[DisplayName("Automatic Read Reallocation")]
		public bool AutomaticReadReallocationEnabled { get { return Bits.GetBit(this.errorRecoveryParameter, 6); } set { this.errorRecoveryParameter = Bits.SetBit(this.errorRecoveryParameter, 6, value); } }
		[DisplayName("Transfer Block")]
		public bool TransferBlock { get { return Bits.GetBit(this.errorRecoveryParameter, 5); } set { this.errorRecoveryParameter = Bits.SetBit(this.errorRecoveryParameter, 5, value); } }
		[DisplayName("Read Continuous")]
		public bool ReadContinuous { get { return Bits.GetBit(this.errorRecoveryParameter, 4); } set { this.errorRecoveryParameter = Bits.SetBit(this.errorRecoveryParameter, 4, value); } }
		[DisplayName("Post Error")]
		public bool PostError { get { return Bits.GetBit(this.errorRecoveryParameter, 2); } set { this.errorRecoveryParameter = Bits.SetBit(this.errorRecoveryParameter, 2, value); } }
		[DisplayName("Disable Transfer On Error")]
		public bool DisableTransferOnError { get { return Bits.GetBit(this.errorRecoveryParameter, 1); } set { this.errorRecoveryParameter = Bits.SetBit(this.errorRecoveryParameter, 1, value); } }
		[DisplayName("Disable Correction")]
		public bool DisableCorrection { get { return Bits.GetBit(this.errorRecoveryParameter, 0); } set { this.errorRecoveryParameter = Bits.SetBit(this.errorRecoveryParameter, 0, value); } }
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private byte _ReadRetryCount;
		[DisplayName("Read Retry Count")]
		public byte ReadRetryCount { get { return this._ReadRetryCount; } set { this._ReadRetryCount = value; } }
		private byte _CorrectionSpan;
		private byte _HeadOffsetCount;
		private byte _DataStrobeOffsetCount;
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private byte byte7;
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private byte _WriteRetryCount;
		[DisplayName("Write Retry Count")]
		public byte WriteRetryCount { get { return this._WriteRetryCount; } set { this._WriteRetryCount = value; } }
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private byte byte9;
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private ushort _RecoveryTimeLimit;
		/// <summary>Should be zero.</summary>
		[DisplayName("Recovery Time Limit")]
		public ushort RecoveryTimeLimit { get { return Bits.BigEndian(this._RecoveryTimeLimit); } set { this._RecoveryTimeLimit = Bits.BigEndian(value); } }
	}
}