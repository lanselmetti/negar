﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Helper;

namespace Scsi.Multimedia
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class Verify10Command : FixedLengthScsiCommand
	{
		public Verify10Command() : base(ScsiCommandCode.Verify10) { }
		public Verify10Command(uint logicalBlockAddress, ushort numberOfBlocks)
			: this()
		{
			this.LogicalBlockAddress = logicalBlockAddress;
			this.NumberOfBlocks = numberOfBlocks;
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private byte byte1;
		/// <summary>Should be zero.</summary>
		public bool DisablePageOut { get { return Bits.GetBit(this.byte1, 4); } set { this.byte1 = Bits.SetBit(this.byte1, 4, value); } }
		/// <summary>Should be zero.</summary>
		public bool ByteCheck { get { return Bits.GetBit(this.byte1, 1); } set { this.byte1 = Bits.SetBit(this.byte1, 1, value); } }
		[Obsolete("Should be zero.", true)]
		public bool RelativeAddress { get { return Bits.GetBit(this.byte1, 0); } set { this.byte1 = Bits.SetBit(this.byte1, 0, value); } }
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private uint _LogicalBlockAddress;
		public uint LogicalBlockAddress { get { return Bits.BigEndian(this._LogicalBlockAddress); } set { this._LogicalBlockAddress = Bits.BigEndian(value); } }
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private byte byte6;
		public bool Group3Timeout { get { return Bits.GetBit(this.byte6, 7); } set { this.byte6 = Bits.SetBit(this.byte6, 7, value); } }
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private ushort _NumberOfBlocks;
		public ushort NumberOfBlocks { get { return Bits.BigEndian(this._NumberOfBlocks); } set { this._NumberOfBlocks = Bits.BigEndian(value); } }
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private CommandControl _Control;
		public override CommandControl Control { get { return this._Control; } set { this._Control = value; } }

		public override ScsiTimeoutGroup TimeoutGroup { get { return ScsiTimeoutGroup.Group2; } }
	}
}