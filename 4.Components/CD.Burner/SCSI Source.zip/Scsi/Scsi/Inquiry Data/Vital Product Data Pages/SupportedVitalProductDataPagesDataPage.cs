﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace Scsi
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public class SupportedVitalProductDataPagesDataPage : VitalProductDataInquiryData
	{
		[DebuggerBrowsableAttribute(DebuggerBrowsableState.Never)]
		private static readonly IntPtr SUPPORTED_PAGE_LIST_OFFSET = Marshal.OffsetOf(typeof(SupportedVitalProductDataPagesDataPage), "_SupportedPageList");

		public SupportedVitalProductDataPagesDataPage() : base(VitalProductDataPageCode.SupportedVitalProductDataPages) { }

		[DebuggerBrowsableAttribute(DebuggerBrowsableState.Never)]
		[MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
		private VitalProductDataPageCode[] _SupportedPageList;
		public VitalProductDataPageCode[] SupportedPageList { get { return this._SupportedPageList; } set { this._SupportedPageList = value; this.PageLength = (byte)(value != null ? value.Length / sizeof(VitalProductDataPageCode) : 0); } }

		protected override void MarshalFrom(Helper.BufferWithSize buffer)
		{
			base.MarshalFrom(buffer);
			this._SupportedPageList = new VitalProductDataPageCode[this.PageLength / sizeof(VitalProductDataPageCode)];
			for (int i = 0; i < this._SupportedPageList.Length; i++)
			{ this._SupportedPageList[i] = (VitalProductDataPageCode)buffer[(int)SUPPORTED_PAGE_LIST_OFFSET + i]; }
		}

		protected override void MarshalTo(Helper.BufferWithSize buffer)
		{
			base.MarshalTo(buffer);
			for (int i = 0; i < this._SupportedPageList.Length; i++)
			{ buffer[(int)SUPPORTED_PAGE_LIST_OFFSET + i] = (byte)this._SupportedPageList[i]; }
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		protected override int MarshaledSize { get { return base.MarshaledSize + this.PageLength - sizeof(VitalProductDataPageCode); } }
	}
}