﻿namespace Helper
{
	public interface ILocatable
	{
		uint Location { get; set; }
	}
}